/*
Author: Pleng Witayaweerasak
Date: 2025-04-07
This class provides a utility to perform background tasks and return the result to the main thread.
*/

// BackgroundTask.java
package com.example.fakestoreapp;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * A utility class to perform background operations and return the result to the main thread.
 * This is a simplified version of AsyncTask which was deprecated in Android API level 30.
 */
public class BackgroundTask<T> {
    private final Supplier<T> backgroundWork;
    private final Consumer<T> postExecute;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    /**
     * Creates a new background task.
     *
     * @param backgroundWork The work to be done in the background thread
     * @param postExecute The work to be done in the UI thread after the background work is complete
     */
    public BackgroundTask(Supplier<T> backgroundWork, Consumer<T> postExecute) {
        this.backgroundWork = backgroundWork;
        this.postExecute = postExecute;
    }

    /**
     * Executes the task.
     */
    public void execute() {
        executor.execute(() -> {
            final T result = backgroundWork.get();
            handler.post(() -> postExecute.accept(result));
        });
    }
}