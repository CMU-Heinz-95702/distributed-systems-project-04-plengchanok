/*
Author: Pleng Witayaweerasak
Date: 2025-04-07
This class provides utility methods for making network requests.
*/

// NetworkUtils.java
package com.example.fakestoreapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Utility class for making network requests.
 */
public class NetworkUtils {
    private static final String BASE_URL = "https://friendly-giggle-6pr5x5jpvxq24vv7-8080.app.github.dev/api/product/";

    /**
     * Fetches product data from the web service.
     *
     * @param productId The ID of the product to fetch
     * @return The JSON response from the web service
     * @throws IOException If an error occurs during the HTTP request
     */
    public static String fetchProduct(String productId) throws IOException {
        URL url = new URL(BASE_URL + productId);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        try {
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream())
                );

                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();
                return response.toString();
            } else {
                throw new IOException("HTTP error code: " + responseCode);
            }

        } finally {
            connection.disconnect();
        }
    }
}