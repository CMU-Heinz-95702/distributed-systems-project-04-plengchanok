/*
Author: Pleng Witayaweerasak
Date: 2025-04-07
This is the main activity of the FakeStoreApp.
It allows users to enter a product ID and fetch product details from the FakeStore API.
*/

// MainActivity.java
package com.example.fakestoreapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private EditText productIdInput;
    private Button fetchButton;
    private TextView productTitle;
    private TextView productPrice;
    private TextView productDescription;
    private ImageView productImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_main);

        // Initialize views
        productIdInput = findViewById(R.id.product_id_input);
        fetchButton = findViewById(R.id.fetch_button);
        productTitle = findViewById(R.id.product_title);
        productPrice = findViewById(R.id.product_price);
        productDescription = findViewById(R.id.product_description);
        productImage = findViewById(R.id.product_image);

        fetchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String productId = productIdInput.getText().toString().trim();

                // Validate input
                if (productId.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a product ID", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int id = Integer.parseInt(productId);
                    if (id < 1 || id > 20) { // FakeStoreAPI has products from 1 to 20
                        Toast.makeText(MainActivity.this, "Product ID must be between 1 and 20", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Execute the API call in background
                    new BackgroundTask<String>(
                            // doInBackground
                            () -> {
                                try {
                                    return NetworkUtils.fetchProduct(productId);
                                } catch (IOException e) {
                                    return null;
                                }
                            },
                            // onPostExecute
                            result -> {
                                if (result == null) {
                                    showError("Network error: Unable to fetch product");
                                    return;
                                }

                                try {
                                    displayProductData(result);
                                } catch (JSONException e) {
                                    showError("Error parsing response: " + e.getMessage());
                                }
                            }
                    ).execute();

                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void displayProductData(String jsonData) throws JSONException {
        JSONObject product = new JSONObject(jsonData);

        productTitle.setText(product.getString("title"));
        productPrice.setText("$" + product.getDouble("price"));
        productDescription.setText(product.getString("description"));

        // Load image with Picasso
        String imageUrl = product.getString("image");
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get()
                    .load(imageUrl)
                    .placeholder(R.drawable.placeholder_image)
                    .error(R.drawable.error_image)
                    .into(productImage);
        } else {
            productImage.setImageResource(R.drawable.no_image);
        }
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        // Clear previous data
        productTitle.setText("Product not found");
        productPrice.setText("");
        productDescription.setText("Please try another product ID");
        productImage.setImageResource(R.drawable.error_image);
    }
}